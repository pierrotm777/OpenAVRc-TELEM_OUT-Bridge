#pragma once

// ============================================================================
// CRSF telemetry input from OpenAVRc
// ============================================================================
// OpenAVRc Serial1:
//   Mega TX1 ---> ESP32-C3 GPIO4 RX
//   Mega RX1 <--- ESP32-C3 GPIO7 TX
//   115200 8N1

#include <Arduino.h>

static constexpr int CRSF_RX_PIN = 4;
static constexpr int CRSF_TX_PIN = 7;
static constexpr uint32_t CRSF_HANDSET_BAUD = 115200UL;

static void crsfBegin(void);
static void crsfProcess(void);

static uint32_t crsfBytesPerSecond(void);
static bool crsfIsReceiving(void);
