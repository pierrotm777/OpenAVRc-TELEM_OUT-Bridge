#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>

/* Pin out ESP32 C3 Oled

4     CRSF_RX_PIN
5     SDA_PIN
6     SCL_PIN
7     CRSF_TX_PIN

*/

float VERSION = 1.0f;
static const char* BUILD_TAG = "1.0-TELEM-C3";

// ============================================================================
// ESP32-C3 Mini pinout
// ============================================================================
// OLED integrated on this ESP32-C3 Mini board.
// Confirmed wiring: SDA=GPIO5, SCL=GPIO6.
static constexpr int SDA_PIN = 5;
static constexpr int SCL_PIN = 6;

static constexpr uint32_t I2C_BUS_HZ = 100000UL;
static constexpr uint32_t DEFAULT_BAUD = 115200;

// OLED
static constexpr uint8_t OLED_ADDR = 0x3C;

#include "BT_LE.h"
#include "CRSF_Main.h"
#include "Console.h"

// Suppress setup chatter. Console remains fully verbose after setup.
static bool StartupConsoleQuiet = true;

static bool oled_ok = false;
static uint32_t oled_last_ms = 0;

U8G2_SSD1306_72X40_ER_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

// ============================================================================
// OLED
// ============================================================================
static uint8_t oledProbeAddress()
{
  const uint8_t candidates[] = { 0x3C, 0x3D };

  for(uint8_t i = 0; i < sizeof(candidates); i++)
  {
    Wire.beginTransmission(candidates[i]);
    if(Wire.endTransmission() == 0)
      return candidates[i];
  }

  return 0;
}

static void oledInit()
{
  Wire.setClock(I2C_BUS_HZ);
  delay(20);

  const uint8_t detectedAddr = oledProbeAddress();
  if(detectedAddr == 0)
  {
    oled_ok = false;
    if(!StartupConsoleQuiet)
      Serial.printf("[OLED] NO I2C device on SDA=%d SCL=%d\r\n",
                    SDA_PIN, SCL_PIN);
    return;
  }

  u8g2.setI2CAddress(detectedAddr << 1);
  u8g2.setBusClock(I2C_BUS_HZ);
  oled_ok = u8g2.begin();

  if(!oled_ok)
  {
    if(!StartupConsoleQuiet)
      Serial.println("[OLED] init FAILED");
    return;
  }

  if(!StartupConsoleQuiet)
    Serial.println("[OLED] init OK (SSD1306 72x40 / U8g2)");

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x7_tf);

  u8g2.setCursor(0, 8);
  u8g2.print("TELEM-C3");

  u8g2.setCursor(0, 18);
  u8g2.print("ESP32-C3");

  u8g2.setCursor(0, 28);
  u8g2.print("OLED OK");

  u8g2.sendBuffer();
  delay(500);
}

static void oledDraw()
{
  if(!oled_ok || (uint32_t)(millis() - oled_last_ms) < 500UL)
    return;

  oled_last_ms = millis();

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x7_tf);

  u8g2.setCursor(0, 7);
  u8g2.print("TELEM_OUT");

  u8g2.setCursor(0, 16);
  u8g2.print("UART:");
  u8g2.print(crsfIsReceiving() ? "RX" : "WAIT");

  u8g2.setCursor(0, 25);
  u8g2.print("RX:");
  u8g2.print(crsfBytesPerSecond());
  u8g2.print("/s");

  u8g2.setCursor(0, 34);
  u8g2.print("BLE:");
  u8g2.print(btIsConnected() ? "OK" : "READY");

  u8g2.sendBuffer();
}

void setup()
{
  Serial.begin(DEFAULT_BAUD); // Use Serial

  // Timeout USB Serial (does not block forever without USB)
  uint32_t t0 = millis();
  while(!Serial && (millis() - t0 < 1500UL))
    delay(1);

  Serial.println();
  Serial.println("***********************************");
  Serial.println("TELEM-C3 - OpenAVRc telemetry bridge");
  Serial.println("***********************************");

  // Shared I2C bus is always started before OLED init.
  Wire.begin(SDA_PIN, SCL_PIN, I2C_BUS_HZ);
  Wire.setClock(I2C_BUS_HZ);

  oledInit();

  // BLE is independent from the UART telemetry input.
  btBegin();

  // OpenAVRc Serial1 -> ESP32-C3 CRSF telemetry input.
  crsfBegin();
  consoleBegin();

  // From this point onward all normal console feedback is enabled again.
  StartupConsoleQuiet = false;

  Serial.printf("[MAIN] %s READY\r\n", BUILD_TAG);
}

void loop()
{
  // Same organisation principle as the validated project:
  // each functional block owns its own process function.
  consoleProcess();
  crsfProcess();
  btProcess();
  oledDraw();
}
