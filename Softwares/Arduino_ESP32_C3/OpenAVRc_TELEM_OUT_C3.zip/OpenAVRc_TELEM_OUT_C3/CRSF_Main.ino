// ============================================================================
// CRSF telemetry input from OpenAVRc
// ============================================================================

#include "CRSF_Main.h"
#include "BT_LE.h"
#include "Console.h"

static HardwareSerial CrsfUart(1);

static constexpr uint8_t CRSF_TYPE_GPS         = 0x02;
static constexpr uint8_t CRSF_TYPE_VARIO       = 0x07;
static constexpr uint8_t CRSF_TYPE_BATTERY     = 0x08;
static constexpr uint8_t CRSF_TYPE_BARO        = 0x09;
static constexpr uint8_t CRSF_TYPE_RPM         = 0x0C;
static constexpr uint8_t CRSF_TYPE_TEMPERATURE = 0x0D;
static constexpr uint8_t CRSF_TYPE_VOLTAGES    = 0x0E;
static constexpr uint8_t CRSF_TYPE_LINK        = 0x14;
static constexpr uint8_t CRSF_TYPE_CHANNELS    = 0x16;

static constexpr uint8_t CRSF_MAX_FRAME = 64;
static constexpr uint32_t CRSF_RX_TIMEOUT_MS = 1500UL;

static uint8_t CrsfFrame[CRSF_MAX_FRAME];
static uint8_t CrsfFramePos = 0;
static uint8_t CrsfFrameTotal = 0;

static uint32_t CrsfTotalBytes = 0;
static uint32_t CrsfBytesThisSecond = 0;
static uint32_t CrsfRxPerSecond = 0;
static uint32_t CrsfLastByteMs = 0;
static uint32_t CrsfLastStatsMs = 0;
static uint32_t CrsfGoodFrames = 0;
static uint32_t CrsfBadCrc = 0;

static uint8_t crsfCrc8(const uint8_t* data, uint8_t len)
{
  uint8_t crc = 0;

  while(len--)
  {
    crc ^= *data++;

    for(uint8_t bit = 0; bit < 8; bit++)
      crc = (crc & 0x80U)
          ? (uint8_t)((crc << 1) ^ 0xD5U)
          : (uint8_t)(crc << 1);
  }

  return crc;
}

static uint16_t crsfReadU16BE(const uint8_t* p)
{
  return ((uint16_t)p[0] << 8) | p[1];
}

static int16_t crsfReadS16BE(const uint8_t* p)
{
  return (int16_t)crsfReadU16BE(p);
}

static int8_t crsfReadS8(const uint8_t* p)
{
  return (int8_t)(*p);
}

static uint32_t crsfReadU24BE(const uint8_t* p)
{
  return ((uint32_t)p[0] << 16) |
         ((uint32_t)p[1] << 8) |
         p[2];
}

static int32_t crsfReadS32BE(const uint8_t* p)
{
  const uint32_t raw =
      ((uint32_t)p[0] << 24) |
      ((uint32_t)p[1] << 16) |
      ((uint32_t)p[2] << 8) |
      p[3];

  return (int32_t)raw;
}

static void crsfPrintHex(const uint8_t* data, uint8_t len)
{
  if(!consoleDebugEnabled())
    return;

  Serial.print("[CRSF] ");

  for(uint8_t i = 0; i < len; i++)
  {
    if(data[i] < 0x10)
      Serial.print('0');

    Serial.print(data[i], HEX);
    Serial.print(' ');
  }

  Serial.println();
}

static void crsfDebugDecodedFrame(const uint8_t* data, uint8_t len)
{
  if(!consoleDebugEnabled())
    return;

  const uint8_t type = data[2];

  if(type == CRSF_TYPE_BATTERY && len >= 12U)
  {
    const uint16_t voltage = crsfReadU16BE(&data[3]);
    const uint16_t current = crsfReadU16BE(&data[5]);
    const uint32_t capacity = crsfReadU24BE(&data[7]);
    const uint8_t remaining = data[10];

    Serial.printf(
      "[BAT] V=%u.%u V  I=%u.%u A  C=%lu mAh  REM=%u%%\r\n",
      voltage / 10U, voltage % 10U,
      current / 10U, current % 10U,
      (unsigned long)capacity,
      remaining
    );
  }
  else if(type == CRSF_TYPE_VARIO && len >= 6U)
  {
    const int16_t vario = crsfReadS16BE(&data[3]);

    Serial.printf(
      "[VARIO] %+d cm/s  (%+.2f m/s)\r\n",
      (int)vario,
      (double)vario / 100.0
    );
  }
  else if(type == CRSF_TYPE_GPS && len >= 19U)
  {
    const int32_t lat = crsfReadS32BE(&data[3]);
    const int32_t lon = crsfReadS32BE(&data[7]);
    const uint16_t speed = crsfReadU16BE(&data[11]);
    const uint16_t heading = crsfReadU16BE(&data[13]);
    const uint16_t altitudeRaw = crsfReadU16BE(&data[15]);
    const uint8_t sats = data[17];

    Serial.printf(
      "[GPS] lat=%.7f lon=%.7f speed=%.1f km/h heading=%.2f deg alt=%ld m sats=%u\r\n",
      (double)lat / 10000000.0,
      (double)lon / 10000000.0,
      (double)speed / 10.0,
      (double)heading / 100.0,
      (long)((int32_t)altitudeRaw - 1000L),
      sats
    );
  }
  else if(type == CRSF_TYPE_BARO && len >= 6U)
  {
    const uint16_t raw = crsfReadU16BE(&data[3]);

    if(raw & 0x8000U)
    {
      const uint16_t metres = raw & 0x7FFFU;
      Serial.printf("[BARO] alt=%u m (whole-metre mode)\r\n", metres);
    }
    else
    {
      const int32_t cm = ((int32_t)raw - 10000L) * 10L;
      Serial.printf("[BARO] alt=%ld cm  (%.2f m)\r\n",
                    (long)cm, (double)cm / 100.0);
    }
  }
  else if(type == CRSF_TYPE_RPM && len >= 8U)
  {
    const uint8_t source = data[3];
    int32_t rpm =
        ((int32_t)data[4] << 16) |
        ((int32_t)data[5] << 8) |
        data[6];

    if(rpm & 0x00800000L)
      rpm |= (int32_t)0xFF000000L;

    Serial.printf("[RPM] src=%u rpm=%ld\r\n",
                  source, (long)rpm);
  }
  else if(type == CRSF_TYPE_TEMPERATURE && (len == 7U || len == 9U))
  {
    const uint8_t source = data[3];
    const int16_t t1 = crsfReadS16BE(&data[4]);

    if(len == 9U)
    {
      const int16_t t2 = crsfReadS16BE(&data[6]);
      Serial.printf("[TEMP] src=%u T1=%.1f C T2=%.1f C\r\n",
                    source,
                    (double)t1 / 10.0,
                    (double)t2 / 10.0);
    }
    else
    {
      Serial.printf("[TEMP] src=%u T=%.1f C\r\n",
                    source,
                    (double)t1 / 10.0);
    }
  }
  else if(type == CRSF_TYPE_VOLTAGES && len >= 7U)
  {
    const uint8_t source = data[3];

    if(source == 128U && len >= 7U)
    {
      const uint16_t mv = crsfReadU16BE(&data[4]);
      Serial.printf("[VOLT] src=128 RxBt=%u mV (%.3f V)\r\n",
                    mv, (double)mv / 1000.0);
    }
    else
    {
      Serial.printf("[CELLS] src=%u", source);

      uint8_t cell = 0;
      for(uint8_t pos = 4U; (uint8_t)(pos + 1U) < (uint8_t)(len - 1U); pos += 2U)
      {
        const uint16_t mv = crsfReadU16BE(&data[pos]);
        Serial.printf(" C%u=%u", (unsigned)(cell + 1U), mv);
        cell++;
      }

      Serial.println(" mV");
    }
  }
  else if(type == CRSF_TYPE_LINK && len >= 14U)
  {
    const uint8_t rssi1 = data[3];
    const uint8_t rssi2 = data[4];
    const uint8_t uplq  = data[5];
    const int8_t  upsnr = crsfReadS8(&data[6]);
    const uint8_t ant   = data[7];
    const uint8_t mode  = data[8];
    const uint8_t pwr   = data[9];
    const uint8_t drssi = data[10];
    const uint8_t dllq  = data[11];
    const int8_t  dlsnr = crsfReadS8(&data[12]);

    Serial.printf(
      "[LINK] RSSI1=-%u RSSI2=-%u UPLQ=%u UPSNR=%d ANT=%u MODE=%u PWR=%u "
      "DLRSSI=-%u DLLQ=%u DLSNR=%d\r\n",
      rssi1, rssi2, uplq, (int)upsnr, ant, mode, pwr,
      drssi, dllq, (int)dlsnr
    );
  }
  else if(type == CRSF_TYPE_CHANNELS && len >= 26U)
  {
    uint16_t ch[16] = {0};
    uint32_t scratch = 0;
    uint8_t bits = 0;
    uint8_t src = 3;

    for(uint8_t i = 0; i < 16U; i++)
    {
      while(bits < 11U && src < (uint8_t)(len - 1U))
      {
        scratch |= ((uint32_t)data[src++]) << bits;
        bits = (uint8_t)(bits + 8U);
      }

      ch[i] = (uint16_t)(scratch & 0x07FFU);
      scratch >>= 11U;
      bits = (uint8_t)(bits - 11U);
    }

    Serial.printf(
      "[CH] 1=%u 2=%u 3=%u 4=%u 5=%u 6=%u 7=%u 8=%u\r\n",
      ch[0], ch[1], ch[2], ch[3],
      ch[4], ch[5], ch[6], ch[7]
    );
  }
}


// ============================================================================
// Telemetry Viewer compatibility
// ============================================================================
// Native CRSF Battery 0x08 is deliberately decoded by Telemetry Viewer as
// VBAT_OR_CELL. Depending on the application's "Report voltage" preference,
// that single voltage feeds either V or V CELL.
//
// Telemetry Viewer also supports ArduPilot passthrough battery word 0x5003
// inside CRSF frame 0x80. That path explicitly publishes:
//   - pack VBAT
//   - current
//   - consumed capacity (mAh)
//   - an inferred cell voltage
//
// Keep the original 0x08 untouched and add this small BLE-only companion frame
// so the application's separate V and capacity widgets can also be populated.
static uint32_t crsfBuildApBatteryWord(uint16_t voltage_dv,
                                       uint16_t current_da,
                                       uint32_t capacity_mah)
{
  // 0x5003 layout used by Telemetry Viewer:
  // bits  1..9  : voltage in 0.1 V (9 bits)
  // bit      10 : current decimal exponent
  // bits 11..17 : current mantissa (7 bits)
  // bits 18..32 : consumed mAh (15 bits)
  //
  // Current representation:
  //   exponent 0 -> mantissa / 10 A  (0.0 .. 12.7 A)
  //   exponent 1 -> mantissa * 1 A   (0 .. 127 A)
  uint16_t v = voltage_dv;
  if(v > 0x01FFU)
    v = 0x01FFU;

  uint8_t ampsMantissa;
  uint8_t ampsExponent;

  if(current_da <= 127U)
  {
    // Preserve 0.1 A resolution.
    ampsMantissa = (uint8_t)current_da;
    ampsExponent = 0U;
  }
  else
  {
    // Above 12.7 A the passthrough word has only 1 A resolution.
    uint16_t wholeAmps = (uint16_t)((current_da + 5U) / 10U);
    if(wholeAmps > 127U)
      wholeAmps = 127U;

    ampsMantissa = (uint8_t)wholeAmps;
    ampsExponent = 1U;
  }

  uint32_t mah = capacity_mah;
  if(mah > 0x7FFFUL)
    mah = 0x7FFFUL;

  return ((uint32_t)v) |
         ((uint32_t)ampsExponent << 9) |
         ((uint32_t)ampsMantissa << 10) |
         (mah << 17);
}

static void crsfSendBleBatteryCompanion(const uint8_t* data, uint8_t len)
{
  if(!data || data[2] != CRSF_TYPE_BATTERY || len < 12U)
    return;

  const uint16_t voltage = crsfReadU16BE(&data[3]);
  const uint16_t current = crsfReadU16BE(&data[5]);
  const uint32_t capacity = crsfReadU24BE(&data[7]);

  const uint32_t word =
      crsfBuildApBatteryWord(voltage, current, capacity);

  // CRSF:
  // [0] address/sync C8
  // [1] length = type(1) + payload(7) + CRC(1) = 9
  // [2] 0x80 ArduPilot custom telemetry
  // payload:
  //   F0            single packet
  //   03 50         AppID 0x5003, little endian
  //   xx xx xx xx   battery word, little endian
  // [10] CRC
  uint8_t frame[11];

  frame[0] = 0xC8U;
  frame[1] = 9U;
  frame[2] = 0x80U;
  frame[3] = 0xF0U;
  frame[4] = 0x03U;
  frame[5] = 0x50U;
  frame[6] = (uint8_t)(word);
  frame[7] = (uint8_t)(word >> 8);
  frame[8] = (uint8_t)(word >> 16);
  frame[9] = (uint8_t)(word >> 24);
  frame[10] = crsfCrc8(&frame[2], 8U);

  btTelemetryCapture(frame, sizeof(frame));

  if(consoleDebugEnabled())
  {
    Serial.printf(
      "[BLE-BAT] +0x80/5003 V=%u.%uV I=%u.%uA C=%lu mAh word=%08lX\r\n",
      voltage / 10U, voltage % 10U,
      current / 10U, current % 10U,
      (unsigned long)capacity,
      (unsigned long)word
    );
  }
}

static void crsfProcessFrame(const uint8_t* data, uint8_t len)
{
  if(!data || len < 4U)
    return;

  if((uint8_t)(data[1] + 2U) != len)
    return;

  const uint8_t calc = crsfCrc8(&data[2], (uint8_t)(len - 3U));
  const uint8_t received = data[len - 1U];

  crsfPrintHex(data, len);

  if(calc != received)
  {
    CrsfBadCrc++;

    if(consoleDebugEnabled())
    {
      Serial.printf(
        "[CRSF] CRC ERROR calc=%02X rx=%02X\r\n",
        calc,
        received
      );
    }

    return;
  }

  CrsfGoodFrames++;

  if(consoleDebugEnabled())
  {
    Serial.printf(
      "[CRSF] OK addr=%02X type=%02X len=%u\r\n",
      data[0],
      data[2],
      len
    );
  }

  crsfDebugDecodedFrame(data, len);

  // For GPS testing we can override only the satellite-count byte sent to BLE.
  // Latitude, longitude, speed, heading and altitude remain untouched.
  if(data[2] == CRSF_TYPE_GPS &&
     len >= 19U &&
     consoleGpsSatOverrideEnabled())
  {
    uint8_t testFrame[CRSF_MAX_FRAME];

    memcpy(testFrame, data, len);

    const uint8_t oldSats = testFrame[17];
    testFrame[17] = consoleGpsSatOverrideValue();

    // CRC covers type + payload, excluding address, length and CRC byte.
    testFrame[len - 1U] =
        crsfCrc8(&testFrame[2], (uint8_t)(len - 3U));

    if(consoleDebugEnabled())
    {
      Serial.printf(
        "[TEST] GPS sats %u -> %u for BLE only, CRC=%02X\r\n",
        oldSats,
        testFrame[17],
        testFrame[len - 1U]
      );
    }

    btTelemetryCapture(testFrame, len);
  }
  else
  {
    if(data[2] == CRSF_TYPE_BATTERY)
    {
      // Telemetry Viewer gives native CRSF 0x08 priority over the
      // ArduPilot passthrough battery 0x5003 companion frame.
      //
      // Keep receiving the native 0x08 from OpenAVRc, but for BLE only,
      // send the 0x5003 companion instead so the app can publish VFAS,
      // current and consumed capacity correctly.
      //
      // The UART input from OpenAVRc is untouched.
      crsfSendBleBatteryCompanion(data, len);

      if(consoleDebugEnabled())
        Serial.println("[BLE-BAT] native 0x08 suppressed for BLE");
    }
    else
    {
      // All non-battery CRSF frames are forwarded unchanged.
      btTelemetryCapture(data, len);
    }
  }
}

static void crsfFeedByte(uint8_t b)
{
  CrsfTotalBytes++;
  CrsfBytesThisSecond++;
  CrsfLastByteMs = millis();

  if(CrsfFramePos == 0)
  {
    CrsfFrame[CrsfFramePos++] = b;
    return;
  }

  if(CrsfFramePos == 1)
  {
    CrsfFrame[CrsfFramePos++] = b;

    if(b < 2U || b > (CRSF_MAX_FRAME - 2U))
    {
      CrsfFramePos = 0;
      CrsfFrameTotal = 0;
      return;
    }

    CrsfFrameTotal = (uint8_t)(b + 2U);
    return;
  }

  CrsfFrame[CrsfFramePos++] = b;

  if(CrsfFramePos >= CrsfFrameTotal)
  {
    crsfProcessFrame(CrsfFrame, CrsfFrameTotal);

    CrsfFramePos = 0;
    CrsfFrameTotal = 0;
  }
}

static void crsfBegin(void)
{
  CrsfUart.begin(
    CRSF_HANDSET_BAUD,
    SERIAL_8N1,
    CRSF_RX_PIN,
    CRSF_TX_PIN
  );

  CrsfLastStatsMs = millis();

  Serial.printf(
    "[CRSF] UART1 %lu baud RX=GPIO%d TX=GPIO%d\r\n",
    (unsigned long)CRSF_HANDSET_BAUD,
    CRSF_RX_PIN,
    CRSF_TX_PIN
  );
}

static void crsfProcess(void)
{
  while(CrsfUart.available())
    crsfFeedByte((uint8_t)CrsfUart.read());

  const uint32_t now = millis();

  if((uint32_t)(now - CrsfLastStatsMs) >= 1000UL)
  {
    CrsfRxPerSecond = CrsfBytesThisSecond;
    CrsfBytesThisSecond = 0;
    CrsfLastStatsMs = now;

    if(consoleDebugEnabled())
    {
      Serial.printf(
        "[STAT] total=%lu rx=%lu octets/s frames=%lu crcErr=%lu\r\n",
        (unsigned long)CrsfTotalBytes,
        (unsigned long)CrsfRxPerSecond,
        (unsigned long)CrsfGoodFrames,
        (unsigned long)CrsfBadCrc
      );
    }
  }
}

static uint32_t crsfBytesPerSecond(void)
{
  return CrsfRxPerSecond;
}

static bool crsfIsReceiving(void)
{
  return CrsfTotalBytes &&
         ((uint32_t)(millis() - CrsfLastByteMs) < CRSF_RX_TIMEOUT_MS);
}
