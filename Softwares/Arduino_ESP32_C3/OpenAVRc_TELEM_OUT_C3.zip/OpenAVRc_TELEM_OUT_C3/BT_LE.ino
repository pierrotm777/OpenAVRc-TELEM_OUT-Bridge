// ============================================================================
// Bluetooth LE telemetry bridge
// ============================================================================

#include "BT_LE.h"
#include "Console.h"

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

static const char* BTLE_DEVICE_NAME = "TELEM-C3";//Nom Bluetooth LE

// Same Nordic-UART-style UUIDs as the previously validated project.
static const char* BTLE_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
static const char* BTLE_TX_UUID      = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

static constexpr uint8_t BTLE_QUEUE_SIZE = 8;
static constexpr uint8_t BTLE_MAX_FRAME = 64;
static constexpr uint8_t BTLE_NOTIFY_CHUNK = 20; // safe even with MTU=23

struct BtLeFrame
{
  uint8_t len;
  uint8_t data[BTLE_MAX_FRAME];
};

static BLEServer* BtLeServer = nullptr;
static BLECharacteristic* BtLeTx = nullptr;
static volatile bool BtLeConnected = false;
static bool BtLeStackStarted = false;

static BtLeFrame BtLeQueue[BTLE_QUEUE_SIZE];
static volatile uint8_t BtLeQueueRead = 0;
static volatile uint8_t BtLeQueueWrite = 0;
static volatile uint8_t BtLeQueueCount = 0;
static portMUX_TYPE BtLeQueueMux = portMUX_INITIALIZER_UNLOCKED;

static uint32_t BtLeFramesCaptured = 0;
static uint32_t BtLeFramesSent = 0;
static uint32_t BtLeFramesDropped = 0;

class BtLeServerCallbacks : public BLEServerCallbacks
{
  void onConnect(BLEServer* server) override
  {
    (void)server;

    BtLeConnected = true;
    Serial.println("[BTLE] CONNECTED");
  }

  void onDisconnect(BLEServer* server) override
  {
    (void)server;

    BtLeConnected = false;
    Serial.println("[BTLE] DISCONNECTED");

    if(BtLeStackStarted)
      BLEDevice::startAdvertising();
  }
};

static BtLeServerCallbacks BtLeCallbacks;

static void btStartStack()
{
  if(BtLeStackStarted)
    return;

  BLEDevice::init(BTLE_DEVICE_NAME);

  BtLeServer = BLEDevice::createServer();
  BtLeServer->setCallbacks(&BtLeCallbacks);

  BLEService* service = BtLeServer->createService(BTLE_SERVICE_UUID);

  BtLeTx = service->createCharacteristic(
      BTLE_TX_UUID,
      BLECharacteristic::PROPERTY_READ |
      BLECharacteristic::PROPERTY_NOTIFY
  );

  BtLeTx->setValue((uint8_t*)"", 0);

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(BTLE_SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();

  BtLeStackStarted = true;
  BtLeConnected = false;

  Serial.printf(
    "[BTLE] ON - advertising as %s\r\n",
    BTLE_DEVICE_NAME
  );
}

static bool btNotifyBytes(const uint8_t* data, uint8_t len)
{
  if(!BtLeConnected || !BtLeTx || !data || !len)
    return false;

  uint8_t offset = 0;

  while(offset < len)
  {
    const uint8_t chunk =
        (uint8_t)min(
          (int)BTLE_NOTIFY_CHUNK,
          (int)(len - offset)
        );

    BtLeTx->setValue(
      (uint8_t*)&data[offset],
      chunk
    );

    BtLeTx->notify();

    offset = (uint8_t)(offset + chunk);

    // Keep notifications ordered on peers that remain at the default MTU=23.
    if(offset < len)
      delay(1);
  }

  return true;
}

static bool btQueuePop(uint8_t* len, uint8_t* data)
{
  if(!len || !data)
    return false;

  bool haveFrame = false;

  portENTER_CRITICAL(&BtLeQueueMux);

  if(BtLeQueueCount)
  {
    const BtLeFrame& frame =
        BtLeQueue[BtLeQueueRead];

    *len = frame.len;
    memcpy(data, frame.data, frame.len);

    BtLeQueueRead =
        (uint8_t)((BtLeQueueRead + 1U) % BTLE_QUEUE_SIZE);

    BtLeQueueCount--;
    haveFrame = true;
  }

  portEXIT_CRITICAL(&BtLeQueueMux);

  return haveFrame;
}

static void btBegin()
{
  btStartStack();
}

static void btProcess()
{
  if(!BtLeConnected || !BtLeTx)
    return;

  uint8_t len = 0;
  uint8_t data[BTLE_MAX_FRAME];

  while(btQueuePop(&len, data))
  {
    if(btNotifyBytes(data, len))
    {
      BtLeFramesSent++;

      if(consoleDebugEnabled())
      {
        Serial.printf(
          "[BTLE] TX CRSF type=%02X len=%u sent=%lu\r\n",
          len >= 3U ? data[2] : 0U,
          len,
          (unsigned long)BtLeFramesSent
        );
      }
    }
  }
}

static bool btIsConnected()
{
  return BtLeConnected;
}

static void btTelemetryCapture(const uint8_t* p, uint8_t len)
{
  if(!p || len < 4U || len > BTLE_MAX_FRAME)
    return;

  BtLeFrame frame;

  frame.len = len;
  memcpy(frame.data, p, len);

  portENTER_CRITICAL(&BtLeQueueMux);

  if(BtLeQueueCount >= BTLE_QUEUE_SIZE)
  {
    // Keep the freshest telemetry. Drop the oldest queued frame.
    BtLeQueueRead =
        (uint8_t)((BtLeQueueRead + 1U) % BTLE_QUEUE_SIZE);

    BtLeQueueCount--;
    BtLeFramesDropped++;
  }

  BtLeQueue[BtLeQueueWrite] = frame;

  BtLeQueueWrite =
      (uint8_t)((BtLeQueueWrite + 1U) % BTLE_QUEUE_SIZE);

  BtLeQueueCount++;
  BtLeFramesCaptured++;

  portEXIT_CRITICAL(&BtLeQueueMux);
}
