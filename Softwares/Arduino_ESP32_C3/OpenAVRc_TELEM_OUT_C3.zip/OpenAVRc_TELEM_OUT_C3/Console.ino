// ============================================================================
// USB Serial console
// ============================================================================

#include "Console.h"
#include "BT_LE.h"
#include "CRSF_Main.h"

static bool ConsoleDebug = false;

static bool GpsSatOverrideEnabled = false;
static uint8_t GpsSatOverride = 10;

static String ConsoleLine;

static void consolePrintHelp()
{
  Serial.println();
  Serial.println("Commands:");
  Serial.println("  help");
  Serial.println("  ?");
  Serial.println("  debug on");
  Serial.println("  debug off");
  Serial.println("  status");
  Serial.println("  gpssat <0..255>");
  Serial.println("  gpssat off");
  Serial.println();
}

static void consolePrintStatus()
{
  Serial.println();
  Serial.println("----- TELEM-C3 STATUS -----");

  Serial.printf("DEBUG      : %s\r\n",
                ConsoleDebug ? "ON" : "OFF");

  Serial.printf("UART       : %s  RX=%lu octets/s\r\n",
                crsfIsReceiving() ? "RX" : "WAIT",
                (unsigned long)crsfBytesPerSecond());

  Serial.printf("BLE        : %s\r\n",
                btIsConnected() ? "CONNECTED" : "READY");

  if(GpsSatOverrideEnabled)
    Serial.printf("GPS SAT    : FORCE %u\r\n", GpsSatOverride);
  else
    Serial.println("GPS SAT    : SOURCE");

  Serial.println("---------------------------");
  Serial.println();
}

static void consoleHandleLine(String line)
{
  line.trim();
  line.toLowerCase();

  if(line.length() == 0)
    return;

  if(line == "help" || line == "?")
  {
    consolePrintHelp();
    return;
  }

  if(line == "debug on")
  {
    ConsoleDebug = true;
    Serial.println("[CONSOLE] debug ON");
    return;
  }

  if(line == "debug off")
  {
    ConsoleDebug = false;
    Serial.println("[CONSOLE] debug OFF");
    return;
  }

  if(line == "status")
  {
    consolePrintStatus();
    return;
  }

  if(line == "gpssat off")
  {
    GpsSatOverrideEnabled = false;
    Serial.println("[TEST] GPS satellite override OFF");
    return;
  }

  if(line.startsWith("gpssat "))
  {
    String arg = line.substring(7);
    arg.trim();

    const long value = arg.toInt();

    if(value < 0 || value > 255)
    {
      Serial.println("[TEST] gpssat value must be 0..255");
      return;
    }

    GpsSatOverride = (uint8_t)value;
    GpsSatOverrideEnabled = true;

    Serial.printf("[TEST] GPS satellites forced to %u for BLE output\r\n",
                  GpsSatOverride);
    return;
  }

  Serial.println("[CONSOLE] unknown command - type help");
}

static void consoleBegin()
{
  ConsoleLine.reserve(64);

  Serial.println("[CONSOLE] ready - type help");
}

static void consoleProcess()
{
  while(Serial.available())
  {
    const char c = (char)Serial.read();

    if(c == '\r')
      continue;

    if(c == '\n')
    {
      consoleHandleLine(ConsoleLine);
      ConsoleLine = "";
      continue;
    }

    if(ConsoleLine.length() < 63)
      ConsoleLine += c;
  }
}

static bool consoleDebugEnabled()
{
  return ConsoleDebug;
}

static bool consoleGpsSatOverrideEnabled()
{
  return GpsSatOverrideEnabled;
}

static uint8_t consoleGpsSatOverrideValue()
{
  return GpsSatOverride;
}
