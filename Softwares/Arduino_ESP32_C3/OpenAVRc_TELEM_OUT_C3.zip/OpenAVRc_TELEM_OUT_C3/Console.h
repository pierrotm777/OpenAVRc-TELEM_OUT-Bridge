#pragma once

// ============================================================================
// USB Serial console
// ============================================================================

#include <Arduino.h>

static void consoleBegin();
static void consoleProcess();

static bool consoleDebugEnabled();

static bool consoleGpsSatOverrideEnabled();
static uint8_t consoleGpsSatOverrideValue();
