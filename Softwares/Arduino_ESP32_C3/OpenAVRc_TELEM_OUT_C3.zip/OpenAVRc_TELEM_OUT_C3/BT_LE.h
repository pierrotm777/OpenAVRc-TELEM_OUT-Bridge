#pragma once

// ============================================================================
// Bluetooth LE telemetry bridge API
// ============================================================================
// Implemented in BT_LE.ino.
// The UART/CRSF input path remains independent; it only copies accepted
// telemetry bytes to a small RAM queue for later BLE transmission.

#include <Arduino.h>

static void btBegin();
static void btProcess();
static bool btIsConnected();
static void btTelemetryCapture(const uint8_t* p, uint8_t len);
